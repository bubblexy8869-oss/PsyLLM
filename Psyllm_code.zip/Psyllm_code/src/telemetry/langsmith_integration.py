from __future__ import annotations
import os
from contextlib import contextmanager
from typing import Any, Dict, Optional, Iterable
from langsmith import Client
from langsmith.run_helpers import traceable

# 单例 client（langsmith 会从环境变量读取 endpoint/api_key/project）
_client: Optional[Client] = None

def get_ls_client() -> Client:
    global _client
    if _client is None:
        _client = Client()
    return _client

@contextmanager
def trace_session(session_id: str, user_id: Optional[str] = None):
    """
    在一次 API 调用（/start、/step、/stream-step）外层包一个“session run”，
    便于在 LangSmith 上把多级子 run 挂在一起。
    """
    client = get_ls_client()
    root = client.create_run(
        name="assessment_session_step",
        run_type="chain",
        inputs={"session_id": session_id, "user_id": user_id},
        project_name=os.getenv("LANGCHAIN_PROJECT"),
        tags=["assessment", "session"],
    )
    try:
        yield root
    finally:
        client.update_run(root.id, end_time="now")

def log_child_run(
    parent_run,
    name: str,
    run_type: str,
    inputs: Dict[str, Any],
    outputs: Optional[Dict[str, Any]] = None,
    tags: Optional[Iterable[str]] = None,
):
    """
    手动创建子 run（用于自定义 LLM、Node、RAG 检索等环节）。
    """
    client = get_ls_client()
    child = client.create_run(
        name=name,
        run_type=run_type,         # "llm" | "chain" | "tool" | "retriever" | "embedding" 等
        inputs=inputs,
        parent_run_id=parent_run.id if parent_run else None,
        project_name=os.getenv("LANGCHAIN_PROJECT"),
        tags=list(tags or []),
    )
    if outputs is not None:
        client.update_run(child.id, outputs=outputs, end_time="now")
    return child

def log_token(parent_run, token: str):
    """
    可选：把流式 token 作为事件附着在某个 run 上（调试好用）。
    """
    try:
        get_ls_client().log_outputs(parent_run.id, {"token": token})
    except Exception:
        pass

# 提供一个装饰器，快速给 agent 函数加 trace
def traceable_agent(name: str):
    def deco(fn):
        @traceable(name=name, tags=["agent"])
        def wrapped(*args, **kwargs):
            return fn(*args, **kwargs)
        return wrapped
    return deco