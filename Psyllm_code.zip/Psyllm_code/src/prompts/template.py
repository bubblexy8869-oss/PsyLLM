"""
提示模板管理器
参考 deer-flow 的提示模板系统，使用 Jinja2 模板引擎
"""

import os
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional, List
from jinja2 import Environment, FileSystemLoader, select_autoescape
from langchain_core.messages import SystemMessage

# 初始化 Jinja2 环境
template_dir = Path(__file__).parent
env = Environment(
    loader=FileSystemLoader(str(template_dir)),
    autoescape=select_autoescape(),
    trim_blocks=True,
    lstrip_blocks=True,
)


def get_prompt_template(template_name: str) -> str:
    """
    使用 Jinja2 加载并返回提示模板
    
    Args:
        template_name: 模板名称，如 "intent/intent_understanding"
        
    Returns:
        渲染后的模板字符串
    """
    try:
        template = env.get_template(f"{template_name}.md")
        return template.render()
    except Exception as e:
        raise ValueError(f"Error loading template {template_name}: {e}")


def apply_prompt_template(
    template_name: str, 
    state: Dict[str, Any], 
    configurable: Optional[Dict[str, Any]] = None
) -> List[Dict[str, str]]:
    """
    应用模板变量到提示模板，返回格式化的消息列表
    
    Args:
        template_name: 要使用的提示模板名称
        state: 包含要替换变量的当前代理状态
        configurable: 可选的配置变量
        
    Returns:
        消息列表，系统提示作为第一条消息
    """
    # 将状态转换为模板渲染的变量字典
    state_vars = {
        "CURRENT_TIME": datetime.now().strftime("%a %b %d %Y %H:%M:%S %z"),
        **state,
    }
    
    # 添加可配置变量
    if configurable:
        state_vars.update(configurable)
    
    try:
        template = env.get_template(f"{template_name}.md")
        system_prompt = template.render(**state_vars)
        
        # 构建消息列表
        messages = [{"role": "system", "content": system_prompt}]
        
        # 如果状态中有消息，添加到列表中
        if "messages" in state:
            messages.extend(state["messages"])
        
        return messages
    except Exception as e:
        raise ValueError(f"Error applying template {template_name}: {e}")


def render_template_content(template_name: str, variables: Optional[Dict[str, Any]] = None) -> str:
    """
    渲染模板内容（不包装成消息格式）
    
    Args:
        template_name: 模板名称
        variables: 模板变量
        
    Returns:
        渲染后的模板内容
    """
    template_vars = variables or {}
    template_vars.setdefault("CURRENT_TIME", datetime.now().strftime("%a %b %d %Y %H:%M:%S %z"))
    
    try:
        template = env.get_template(f"{template_name}.md")
        return template.render(**template_vars)
    except Exception as e:
        raise ValueError(f"Error rendering template {template_name}: {e}")