"""
JSON工具函数
参考deer-flow的JSON处理实现
"""

import logging
import json
from typing import Any, Dict, Union

logger = logging.getLogger(__name__)


def repair_json_output(content: str) -> str:
    """
    修复和规范化JSON输出
    
    Args:
        content (str): 可能包含JSON的字符串内容
        
    Returns:
        str: 修复后的JSON字符串，如果不是JSON则返回原内容
    """
    content = content.strip()
    if content.startswith(("{", "[")) or "```json" in content or "```ts" in content:
        try:
            # 如果内容被包裹在```json代码块中，提取JSON部分
            if content.startswith("```json"):
                content = content.removeprefix("```json")
            
            if content.startswith("```ts"):
                content = content.removeprefix("```ts")
                
            if content.endswith("```"):
                content = content.removesuffix("```")
            
            # 尝试解析JSON
            parsed_content = json.loads(content)
            return json.dumps(parsed_content, ensure_ascii=False, indent=2)
            
        except json.JSONDecodeError as e:
            logger.warning(f"JSON解析失败: {e}")
            # 尝试基本的JSON修复
            try:
                # 移除可能的尾随逗号
                content = content.rstrip(",")
                # 尝试再次解析
                parsed_content = json.loads(content)
                return json.dumps(parsed_content, ensure_ascii=False, indent=2)
            except json.JSONDecodeError:
                logger.warning("JSON修复失败，返回原内容")
                
    return content


def safe_json_loads(content: str, default: Any = None) -> Any:
    """
    安全地解析JSON字符串
    
    Args:
        content (str): JSON字符串
        default (Any): 解析失败时的默认值
        
    Returns:
        Any: 解析后的对象或默认值
    """
    try:
        return json.loads(content)
    except (json.JSONDecodeError, TypeError) as e:
        logger.warning(f"JSON解析失败: {e}")
        return default


def safe_json_dumps(obj: Any, default: str = "{}") -> str:
    """
    安全地序列化对象为JSON字符串
    
    Args:
        obj (Any): 要序列化的对象
        default (str): 序列化失败时的默认值
        
    Returns:
        str: JSON字符串或默认值
    """
    try:
        return json.dumps(obj, ensure_ascii=False, indent=2)
    except (TypeError, ValueError) as e:
        logger.warning(f"JSON序列化失败: {e}")
        return default


def extract_json_from_text(text: str) -> Union[Dict, list, None]:
    """
    从文本中提取JSON对象
    
    Args:
        text (str): 包含JSON的文本
        
    Returns:
        Union[Dict, list, None]: 提取的JSON对象，如果没有找到则返回None
    """
    # 尝试找到JSON块
    start_markers = ['{', '[']
    end_markers = ['}', ']']
    
    for start_marker, end_marker in zip(start_markers, end_markers):
        start_idx = text.find(start_marker)
        if start_idx != -1:
            # 找到匹配的结束标记
            bracket_count = 0
            for i, char in enumerate(text[start_idx:], start_idx):
                if char == start_marker:
                    bracket_count += 1
                elif char == end_marker:
                    bracket_count -= 1
                    if bracket_count == 0:
                        json_str = text[start_idx:i+1]
                        try:
                            return json.loads(json_str)
                        except json.JSONDecodeError:
                            continue
    
    return None


def merge_json_objects(obj1: Dict, obj2: Dict) -> Dict:
    """
    合并两个JSON对象
    
    Args:
        obj1 (Dict): 第一个对象
        obj2 (Dict): 第二个对象
        
    Returns:
        Dict: 合并后的对象
    """
    result = obj1.copy()
    
    for key, value in obj2.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = merge_json_objects(result[key], value)
        else:
            result[key] = value
    
    return result