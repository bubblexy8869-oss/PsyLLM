# src/utils/prompt_utils.py
from __future__ import annotations
import json
from typing import Any, Dict, Callable
from prompts.template import apply_prompt_template

def render_prompt(name: str, state: Dict[str, Any]) -> str:
    """
    渲染提示模板并返回字符串内容
    
    Args:
        name: 模板名称
        state: 状态变量
        
    Returns:
        渲染后的提示字符串
    """
    from prompts.template import render_template_content
    return render_template_content(name, state)

def safe_json(s: str) -> Dict[str, Any]:
    # 首先检查是否是生成器/迭代器对象
    if hasattr(s, '__iter__') and not isinstance(s, (str, bytes)):
        try:
            s = ''.join(str(chunk) for chunk in s)
        except Exception:
            s = str(s)
    
    # 确保s是字符串
    if not isinstance(s, str):
        s = str(s)
    
    # 尝试直接解析JSON
    try:
        return json.loads(s)
    except Exception:
        pass
    
    # 如果失败，尝试提取JSON部分
    try:
        i, j = s.find("{"), s.rfind("}")
        if i != -1 and j != -1 and j > i:
            return json.loads(s[i:j+1])
    except Exception:
        pass
    
    return {}

def call_json_with_stream_legacy(llm_client, prompt, on_token: Callable[[str], None] | None = None) -> Dict[str, Any]:
    """
    调用LLM客户端并返回JSON解析结果
    
    Args:
        llm_client: LLM客户端实例
        prompt: 可以是字符串或消息列表
        on_token: 可选的token回调函数
        
    Returns:
        解析后的JSON字典
    """
    # 处理消息列表格式
    if isinstance(prompt, list):
        # 如果是消息列表，提取内容并合并
        content_parts = []
        for msg in prompt:
            if isinstance(msg, dict) and "content" in msg:
                content_parts.append(msg["content"])
            elif isinstance(msg, str):
                content_parts.append(msg)
        prompt = "\n\n".join(content_parts)
    
    # 确保prompt是字符串
    if not isinstance(prompt, str):
        prompt = str(prompt)
    
    text = None
    if hasattr(llm_client, "stream"):
        text = llm_client.stream(prompt, on_token or (lambda _: None))
    else:
        text = llm_client.invoke(prompt)
        if on_token: on_token(text)
    return safe_json(text or "")