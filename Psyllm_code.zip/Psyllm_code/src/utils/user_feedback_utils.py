"""
用户反馈工具模块
提供用户反馈处理的通用工具和辅助函数
"""

import logging
from typing import Dict, Any, List, Optional
from datetime import datetime
from graph.types import TaskExecutionState

logger = logging.getLogger(__name__)


def record_user_feedback(
    state: TaskExecutionState,
    feedback_type: str,
    user_input: str,
    parsed_feedback: Dict[str, Any],
    result: str = "processed"
) -> None:
    """
    记录用户反馈到历史记录中
    
    Args:
        state: 任务执行状态
        feedback_type: 反馈类型
        user_input: 用户原始输入
        parsed_feedback: 解析后的反馈内容
        result: 处理结果
    """
    if "user_feedback_history" not in state:
        state["user_feedback_history"] = []
    
    feedback_record = {
        "timestamp": datetime.now().isoformat(),
        "feedback_type": feedback_type,
        "user_input": user_input,
        "parsed_feedback": parsed_feedback,
        "result": result,
        "task_id": state.get("task_id", "")
    }
    
    state["user_feedback_history"].append(feedback_record)
    logger.info(f"记录用户反馈: {feedback_type} - {result}")


def get_feedback_statistics(state: TaskExecutionState) -> Dict[str, Any]:
    """
    获取用户反馈统计信息
    
    Args:
        state: 任务执行状态
        
    Returns:
        反馈统计信息
    """
    history = state.get("user_feedback_history", [])
    
    if not history:
        return {"total_feedbacks": 0}
    
    stats = {
        "total_feedbacks": len(history),
        "feedback_types": {},
        "results": {},
        "first_feedback_time": None,
        "last_feedback_time": None
    }
    
    # 统计反馈类型
    for record in history:
        feedback_type = record.get("feedback_type", "unknown")
        result = record.get("result", "unknown")
        
        if feedback_type not in stats["feedback_types"]:
            stats["feedback_types"][feedback_type] = 0
        stats["feedback_types"][feedback_type] += 1
        
        if result not in stats["results"]:
            stats["results"][result] = 0
        stats["results"][result] += 1
    
    # 时间统计
    if history:
        stats["first_feedback_time"] = history[0].get("timestamp")
        stats["last_feedback_time"] = history[-1].get("timestamp")
    
    return stats


def format_simple_feedback_request(
    user_command: str,
    interaction_type: str,
    context_info: Dict[str, Any]
) -> str:
    """
    格式化简化的反馈请求消息
    
    Args:
        user_command: 用户指令
        interaction_type: 交互类型
        context_info: 上下文信息
        
    Returns:
        格式化的反馈请求消息
    """
    message = f"""## 用户确认需求

**任务指令**: {user_command}
**交互类型**: {interaction_type}

"""
    
    # 根据交互类型显示具体信息
    if interaction_type == "parameter_confirm":
        extracted_params = context_info.get("extracted_parameters", {})
        missing_params = context_info.get("missing_parameters", [])
        confidence = context_info.get("confidence_score", 0)
        
        message += f"""**当前情况**: 参数确认
**置信度**: {confidence:.2f}

**已识别参数**:
"""
        for key, value in extracted_params.items():
            message += f"- {key}: {value}\n"
        
        if missing_params:
            message += f"\n**缺失参数**: {', '.join(missing_params)}\n"
        
        message += f"""
**修改说明**: 如选择修改，请提供参数，格式: key1=value1,key2=value2
"""
    
    elif interaction_type == "classification_confirm":
        suggested_type = context_info.get("suggested_classification", "")
        confidence = context_info.get("confidence_score", 0)
        uncertainty_reason = context_info.get("uncertainty_reason", "")
        
        message += f"""**当前情况**: 意图分类确认
**建议分类**: {suggested_type}
**置信度**: {confidence:.2f}
**原因**: {uncertainty_reason}

**修改说明**: 如选择修改，请提供新的分类类型 (single_command/workflow_template/knowledge_qa/complex_task)
"""
    
    else:
        message += f"""**当前情况**: {interaction_type}
**修改说明**: 如选择修改，请提供具体修改内容
"""
    
    # 统一的操作选择
    message += f"""
**请选择操作**:
- `[CONFIRM]` - 确认当前状态，继续执行
- `[CANCEL]` - 取消任务
- `[MODIFY] 修改内容` - 修改并继续

**示例**:
- `[CONFIRM]`
- `[CANCEL]`
- `[MODIFY] target_id=TARGET_2005,area=Zone_B` (参数场景)
- `[MODIFY] single_command` (分类场景)
"""
    
    return message


def validate_user_feedback_format(user_input: str) -> Dict[str, Any]:
    """
    验证用户反馈格式 (简化版)
    
    Args:
        user_input: 用户输入
        
    Returns:
        验证结果字典，包含is_valid, action, data, error_message
    """
    if not user_input or not user_input.strip():
        return {
            "is_valid": False,
            "action": None,
            "data": None,
            "error_message": "用户输入为空"
        }
    
    user_input = user_input.strip()
    user_input_upper = user_input.upper()
    
    # 检查3种核心操作
    if user_input_upper.startswith("[CONFIRM]"):
        return {
            "is_valid": True,
            "action": "confirm",
            "data": None,
            "error_message": None
        }
    
    elif user_input_upper.startswith("[CANCEL]"):
        return {
            "is_valid": True,
            "action": "cancel",
            "data": None,
            "error_message": None
        }
    
    elif user_input_upper.startswith("[MODIFY]"):
        data_part = user_input[8:].strip()  # 去掉 "[MODIFY] " 前缀
        if not data_part:
            return {
                "is_valid": False,
                "action": "modify",
                "data": None,
                "error_message": "[MODIFY] 操作需要提供修改内容"
            }
        
        return {
            "is_valid": True,
            "action": "modify",
            "data": data_part,
            "error_message": None
        }
    
    # 默认当作修改内容
    return {
        "is_valid": True,
        "action": "modify",
        "data": user_input,
        "error_message": None
    }


def extract_parameters_from_input(param_string: str) -> Dict[str, str]:
    """
    从用户输入中提取参数
    
    Args:
        param_string: 参数字符串，格式如 "key1=value1,key2=value2"
        
    Returns:
        提取的参数字典
    """
    params = {}
    
    if not param_string:
        return params
    
    # 分割参数对
    param_pairs = param_string.split(',')
    
    for pair in param_pairs:
        pair = pair.strip()
        if '=' in pair:
            key, value = pair.split('=', 1)
            params[key.strip()] = value.strip()
        else:
            # 如果没有等号，将整个字符串作为value，key为空
            logger.warning(f"参数格式不正确: {pair}")
    
    return params


def check_interaction_timeout(state: TaskExecutionState, timeout_minutes: int = 30) -> bool:
    """
    检查用户交互是否超时
    
    Args:
        state: 任务执行状态
        timeout_minutes: 超时时间（分钟）
        
    Returns:
        是否超时
    """
    if not state.get("requires_interaction", False):
        return False
    
    # 获取最近的执行结果中的时间戳
    execution_results = state.get("execution_results", [])
    if not execution_results:
        return False
    
    # 查找最近的用户交互请求时间
    latest_interaction_time = None
    for result in reversed(execution_results):
        if (result.get("node_name") == "user_feedback" and 
            result.get("status") == "waiting"):
            latest_interaction_time = result.get("timestamp")
            break
    
    if not latest_interaction_time:
        return False
    
    try:
        from datetime import datetime, timedelta
        
        # 解析时间戳
        interaction_time = datetime.fromisoformat(latest_interaction_time.replace('Z', '+00:00'))
        current_time = datetime.now(interaction_time.tzinfo)
        
        # 检查是否超时
        time_diff = current_time - interaction_time
        return time_diff > timedelta(minutes=timeout_minutes)
    
    except Exception as e:
        logger.error(f"检查交互超时时出错: {e}")
        return False


def create_interaction_context(
    state: TaskExecutionState,
    interaction_type: str,
    additional_data: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    创建交互上下文数据
    
    Args:
        state: 任务执行状态
        interaction_type: 交互类型
        additional_data: 额外数据
        
    Returns:
        交互上下文字典
    """
    context = {
        "task_id": state.get("task_id", ""),
        "user_command": state.get("user_command", ""),
        "interaction_type": interaction_type,
        "timestamp": datetime.now().isoformat(),
        "execution_type": state.get("execution_type", ""),
        "confidence_score": state.get("confidence_score", 0.0)
    }
    
    # 根据交互类型添加特定数据
    if interaction_type == "parameter_confirm":
        context.update({
            "extracted_parameters": state.get("extracted_parameters", {}),
            "missing_parameters": state.get("missing_parameters", []),
            "uncertainty_reason": state.get("uncertainty_reason", "")
        })
    
    elif interaction_type == "classification_confirm":
        context.update({
            "suggested_classification": state.get("execution_type", ""),
            "uncertainty_reason": state.get("uncertainty_reason", "")
        })
    
    elif interaction_type == "plan_approval":
        context.update({
            "task_decomposition": state.get("task_decomposition", {}),
            "subtasks": state.get("subtasks", [])
        })
    
    elif interaction_type == "resource_approval":
        context.update({
            "required_resources": state.get("required_resources", []),
            "device_allocation": state.get("device_allocation", {})
        })
    
    elif interaction_type == "workflow_preview":
        context.update({
            "dynamic_workflow_definition": state.get("dynamic_workflow_definition", {}),
            "workflow_preview_data": state.get("workflow_preview_data", {})
        })
    
    # 添加额外数据
    if additional_data:
        context.update(additional_data)
    
    return context