
from __future__ import annotations

from dataclasses import dataclass, asdict
from enum import Enum
from typing import Any, Dict, Optional
import json
import time


class StreamEventType(str, Enum):
    state = "state"            # 状态快照（profile/进度/当前题号等）
    token = "token"            # LLM token 流
    node_start = "node_start"  # 图节点开始
    node_end = "node_end"      # 图节点结束
    score = "score"            # 单题打分结果
    summary = "summary"        # 维度/阶段小结或报告片段
    error = "error"            # 标准化错误
    done = "done"              # 工作流完成
    heartbeat = "heartbeat"    # 心跳（保持连接）


@dataclass
class StreamEvent:
    type: StreamEventType
    payload: Dict[str, Any]
    thread_id: Optional[str] = None
    node: Optional[str] = None
    ts: float = 0.0

    def to_json(self) -> str:
        if not self.ts:
            self.ts = time.time()
        obj = {
            "type": self.type.value if isinstance(self.type, StreamEventType) else str(self.type),
            "payload": self.payload or {},
            "thread_id": self.thread_id,
            "node": self.node,
            "ts": self.ts,
        }
        return json.dumps(obj, ensure_ascii=False)
