from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any, Optional, Iterable
import os, json, csv
from pathlib import Path

try:
    import yaml  # pip install pyyaml
except Exception:
    yaml = None

@dataclass
class QuestionItem:
    id: str
    text: str
    dimension: str              # 维度：沟通/信任/亲密/子女教育/冲突处理/价值观角色分工 ……
    reverse_scored: bool = False
    weight: float = 1.0

# 维度规格化（支持中英文别名）
DIM_NORMALIZE = {
    # 中文
    "沟通": "communication",
    "信任": "trust",
    "亲密": "intimacy",
    "亲密/性生活": "intimacy",
    "性生活": "intimacy",
    "子女教育": "parenting",
    "冲突处理": "conflict",
    "价值观": "values_roles",
    "角色分工": "values_roles",
    "价值观/角色分工": "values_roles",
    # 英文
    "communication": "communication",
    "trust": "trust",
    "intimacy": "intimacy",
    "parenting": "parenting",
    "conflict": "conflict",
    "values_roles": "values_roles",
    "values": "values_roles",
    "roles": "values_roles",
}

# 意图到维度的默认映射（可按需增补）
INTENT_TO_DIM = {
    "沟通": "communication", "communication": "communication",
    "信任": "trust", "trust": "trust",
    "亲密": "intimacy", "性生活": "intimacy", "intimacy": "intimacy",
    "子女教育": "parenting", "parenting": "parenting",
    "冲突": "conflict", "冲突处理": "conflict", "conflict": "conflict",
    "价值观": "values_roles", "角色分工": "values_roles", "values": "values_roles", "values_roles": "values_roles",
}

def _norm_dim(name: str) -> str:
    return DIM_NORMALIZE.get((name or "").strip(), (name or "").strip())

def _coerce_bool(x: Any) -> bool:
    if isinstance(x, bool): return x
    s = str(x).strip().lower()
    return s in ("1","true","yes","y","t")

def load_question_bank(path: str | Path) -> List[QuestionItem]:
    """
    支持三种格式：
    - YAML: items: [{id, text, dimension, reverse_scored, weight}]
    - JSON: 同上结构
    - CSV : 表头含 id,text,dimension,reverse_scored,weight
    """
    p = Path(path)
    if not p.exists():
        # 返回一个最小 demo，避免阻断流程
        return [
            QuestionItem(id="Q02", text="与配偶交谈是一件轻松愉快的事。", dimension="communication", reverse_scored=False, weight=1.0),
            QuestionItem(id="Q42", text="我能向配偶坦然地表达我的真实需要。", dimension="communication", reverse_scored=False, weight=1.0),
            QuestionItem(id="Q55", text="我很难相信配偶告诉我的每一件事。", dimension="trust", reverse_scored=True, weight=1.0),
            QuestionItem(id="Q35", text="我有时担心配偶会有寻求婚外性关系的想法。", dimension="trust", reverse_scored=True, weight=1.0),
        ]

    suffix = p.suffix.lower()
    if suffix in (".yaml", ".yml"):
        if yaml is None:
            raise RuntimeError("需要 pyyaml：pip install pyyaml")
        data = yaml.safe_load(p.read_text(encoding="utf-8"))
        items = data.get("items", data) if isinstance(data, dict) else data
        return [
            QuestionItem(
                id=str(it["id"]).strip(),
                text=str(it["text"]).strip(),
                dimension=_norm_dim(it.get("dimension","")),
                reverse_scored=_coerce_bool(it.get("reverse_scored", False)),
                weight=float(it.get("weight", 1.0)),
            ) for it in items
        ]
    if suffix == ".json":
        data = json.loads(p.read_text(encoding="utf-8"))
        items = data.get("items", data) if isinstance(data, dict) else data
        return [
            QuestionItem(
                id=str(it["id"]).strip(),
                text=str(it["text"]).strip(),
                dimension=_norm_dim(it.get("dimension","")),
                reverse_scored=_coerce_bool(it.get("reverse_scored", False)),
                weight=float(it.get("weight", 1.0)),
            ) for it in items
        ]
    if suffix == ".csv":
        rows = []
        with p.open("r", encoding="utf-8") as f:
            rdr = csv.DictReader(f)
            for r in rdr: rows.append(r)
        return [
            QuestionItem(
                id=str(r.get("id","")).strip(),
                text=str(r.get("text","")).strip(),
                dimension=_norm_dim(r.get("dimension","")),
                reverse_scored=_coerce_bool(r.get("reverse_scored", False)),
                weight=float(r.get("weight", 1.0)),
            ) for r in rows
        ]
    raise ValueError(f"不支持的题库格式: {p}")

def select_plan_for_intents(
    bank: List[QuestionItem],
    primary_intent: Optional[str],
    intents: Optional[List[Dict[str, Any]]] = None,
    per_dim: int = 10,
) -> List[Dict[str, Any]]:
    """
    规则：
    1) 若有 primary_intent，优先该维度抽题 per_dim
    2) 如果 intents 里还有高置信度的次要维度，可各抽少量（比如 3-5）
    3) 没命中就回退到“沟通”或 bank 前一些题
    """
    dim_primary = INTENT_TO_DIM.get((primary_intent or "").strip(), None)

    # 各维度题目列表
    by_dim: Dict[str, List[QuestionItem]] = {}
    for q in bank:
        by_dim.setdefault(q.dimension, []).append(q)

    plan: List[Dict[str, Any]] = []

    def _pick(dim: str, k: int):
        lst = by_dim.get(dim, [])[:]
        # 简单做个稳定采样：按 id 排序后取前 k
        lst.sort(key=lambda x: x.id)
        for q in lst[:max(0, k)]:
            plan.append({
                "dimension": q.dimension,
                "question_id": q.id,
                "question_text": q.text,
                "weight": q.weight,
                "reverse_scored": q.reverse_scored,
            })

    if dim_primary:
        _pick(dim_primary, per_dim)

    # 选次要维度（如果有）
    if intents:
        # 取与 primary 不同且置信度高的 1-2 个维度，各抽 3-5 题
        others = []
        for it in intents:
            name = it.get("name") or it.get("intent") or it.get("label")
            score = float(it.get("confidence", it.get("score", 0.0)) or 0.0)
            d = INTENT_TO_DIM.get((name or "").strip(), None)
            if d and d != dim_primary:
                others.append((d, score))
        # 按置信度排序
        others.sort(key=lambda x: x[1], reverse=True)
        for i, (d, _) in enumerate(others[:2]):
            _pick(d, 4)  # 次要维度默认 4 题

    # 如果还没凑够，做兜底
    if not plan:
        # 优先沟通维度
        if "communication" in by_dim:
            _pick("communication", per_dim)
        else:
            # 直接取 bank 前 per_dim
            bank_sorted = sorted(bank, key=lambda x: x.id)[:per_dim]
            for q in bank_sorted:
                plan.append({
                    "dimension": q.dimension, "question_id": q.id, "question_text": q.text,
                    "weight": q.weight, "reverse_scored": q.reverse_scored
                })

    return plan