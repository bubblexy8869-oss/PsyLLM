
from __future__ import annotations

import asyncio
import json
import logging
import time
from typing import AsyncGenerator, Optional, Dict, Any

from fastapi.responses import StreamingResponse

from .event_types import StreamEvent, StreamEventType

logger = logging.getLogger(__name__)


def _format_sse(event: StreamEvent, event_id: Optional[str] = None, retry_ms: Optional[int] = None) -> bytes:
    """Encode one SSE frame.
    event: <type>\n
    id: <id>\n
    retry: <ms>\n
    data: <json>\n
    \n
    """
    lines = []
    if event.type:
        lines.append(f"event: {event.type.value}")
    if event_id:
        lines.append(f"id: {event_id}")
    if retry_ms:
        lines.append(f"retry: {retry_ms}")
    payload = event.to_json()
    lines.append(f"data: {payload}")
    frame = ("\n".join(lines) + "\n\n").encode("utf-8")
    return frame


class SSEStreamer:
    """SSE streaming adapter with backpressure queue and heartbeat."""
    def __init__(
        self,
        thread_id: str,
        keepalive_sec: int = 15,
        max_queue: int = 1000,
        client_retry_ms: int = 5000,
    ) -> None:
        self.thread_id = thread_id
        self.keepalive_sec = keepalive_sec
        self.queue: asyncio.Queue[bytes] = asyncio.Queue(maxsize=max_queue)
        self._closed = asyncio.Event()
        self._last_sent = time.time()
        self._client_retry_ms = client_retry_ms
        self._bg_tasks: set[asyncio.Task] = set()

    async def _put_frame(self, frame: bytes) -> None:
        try:
            await self.queue.put(frame)
        except asyncio.CancelledError:
            raise
        except Exception as e:
            logger.exception("enqueue failed: %s", e)

    async def send(self, event: StreamEvent) -> None:
        if self._closed.is_set():
            return
        event.thread_id = event.thread_id or self.thread_id
        frame = _format_sse(event, event_id=self.thread_id, retry_ms=self._client_retry_ms)
        await self._put_frame(frame)
        self._last_sent = time.time()

    async def send_json(self, type_: StreamEventType, payload: Dict[str, Any], node: Optional[str] = None) -> None:
        await self.send(StreamEvent(type=type_, payload=payload, node=node))

    async def heartbeat(self) -> None:
        await self.send_json(StreamEventType.heartbeat, {"ok": True, "ts": time.time()})

    async def close(self) -> None:
        self._closed.set()
        try:
            await self._put_frame(b"\n")
        except Exception:
            pass
        for t in list(self._bg_tasks):
            t.cancel()

    async def iterate(self) -> AsyncGenerator[bytes, None]:
        """Async generator used by FastAPI StreamingResponse."""
        async def _hb():
            try:
                while not self._closed.is_set():
                    await asyncio.sleep(self.keepalive_sec)
                    if time.time() - self._last_sent >= self.keepalive_sec:
                        await self.heartbeat()
            except asyncio.CancelledError:
                return
        hb_task = asyncio.create_task(_hb())
        self._bg_tasks.add(hb_task)
        try:
            while not self._closed.is_set():
                chunk = await self.queue.get()
                yield chunk
                self.queue.task_done()
        except asyncio.CancelledError:
            logger.info("SSE iterate cancelled: %s", self.thread_id)
        finally:
            self._closed.set()
            hb_task.cancel()

    def to_response(self) -> StreamingResponse:
        headers = {
            "Cache-Control": "no-cache, no-transform",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        }
        return StreamingResponse(self.iterate(), media_type="text/event-stream", headers=headers)
