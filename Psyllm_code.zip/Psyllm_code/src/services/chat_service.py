
from __future__ import annotations

import asyncio
import logging
from typing import Any, Callable, Dict

from .event_types import StreamEvent, StreamEventType
from .stream_service import SSEStreamer

logger = logging.getLogger(__name__)


class ChatService:
    """将一次评估请求接入 LangGraph 工作流，并以 SSE 流式返回事件。"""

    def __init__(self, keepalive_sec: int = 15) -> None:
        self.keepalive_sec = keepalive_sec

    async def execute_task_stream(self, request: Dict[str, Any]) -> "StreamingResponse":
        """入口：返回 FastAPI StreamingResponse（SSE）。

        request 示例（可根据你的前端实际扩展）：
        {
            "thread_id": "S-20250907-001",
            "user_id": "U-xxx",
            "payload": { ... 初始输入 ... }
        }
        """
        thread_id = str(request.get("thread_id") or request.get("session_id") or "THR-unknown")
        streamer = SSEStreamer(thread_id=thread_id, keepalive_sec=self.keepalive_sec)

        async def _runner():
            try:
                # 该入口已移除工作流依赖，如需自定义服务侧串联，请在此实现
                raise NotImplementedError(
                    "ChatService.execute_task_stream is deprecated; use LangGraph Studio/Assistants API instead."
                )
            except asyncio.CancelledError:
                logger.info("workflow cancelled: %s", thread_id)
            except Exception as e:
                logger.exception("workflow error: %s", e)
                await streamer.send(StreamEvent(type=StreamEventType.error, payload={"message": str(e)}))
            finally:
                await streamer.send(StreamEvent(type=StreamEventType.done, payload={"ok": True}))
                await streamer.close()

        asyncio.create_task(_runner())
        return streamer.to_response()
