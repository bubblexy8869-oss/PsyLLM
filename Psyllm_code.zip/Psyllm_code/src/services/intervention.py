
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple
import re
import yaml
import os

# ---- Severity normalization --------------------------------------------------

_CN_TO_LEVEL = {
    "严重": "high",
    "中度": "mid",
    "良好": "low",
    "轻度": "low",
    "正常": "low",
}
_LEVELS = {"high", "mid", "low"}

def normalize_severity(s: str) -> str:
    s = str(s).strip().lower()
    # chinese map
    for k, v in _CN_TO_LEVEL.items():
        if s == k.lower():
            return v
    # common english aliases
    aliases = {
        "severe": "high",
        "high": "high",
        "medium": "mid",
        "moderate": "mid",
        "mid": "mid",
        "low": "low",
        "mild": "low",
        "good": "low",
    }
    return aliases.get(s, s)

# ---- Data model --------------------------------------------------------------

@dataclass
class Plan:
    id: str
    applies_if: str
    summary: str
    steps: List[str]
    scripts: Dict[str, str]

# ---- Rule evaluator (very small, safe) --------------------------------------
# supports: "dimension==communication && severity==high" with &&, ||, ==, parentheses

_TOKEN_SPEC = [
    ("WS", r"\s+"),
    ("AND", r"&&"),
    ("OR", r"\|\|"),
    ("EQ", r"=="),
    ("LP", r"\("),
    ("RP", r"\)"),
    ("IDENT", r"[A-Za-z_][A-Za-z0-9_]*"),
    ("STR", r"'[^']*'|\"[^\"]*\""),
]
_TOKEN_RE = re.compile("|".join("(?P<%s>%s)" % t for t in _TOKEN_SPEC))

def _tokenize(expr: str):
    for m in _TOKEN_RE.finditer(expr):
        kind = m.lastgroup
        value = m.group()
        if kind == "WS":
            continue
        yield (kind, value)
    yield ("EOF", "")

class _Parser:
    def __init__(self, tokens):
        self.tokens = iter(tokens)
        self.curr = None
        self._advance()
    def _advance(self):
        self.curr = next(self.tokens)
    def _accept(self, kind):
        if self.curr[0] == kind:
            self._advance()
            return True
        return False
    def _expect(self, kind):
        if not self._accept(kind):
            raise SyntaxError(f"Expected {kind}, got {self.curr}")
    # expr := term { OR term }
    def parse(self):
        node = self.term()
        while self.curr[0] == "OR":
            self._advance()
            right = self.term()
            node = ("OR", node, right)
        return node
    # term := factor { AND factor }
    def term(self):
        node = self.factor()
        while self.curr[0] == "AND":
            self._advance()
            right = self.factor()
            node = ("AND", node, right)
        return node
    # factor := ( expr ) | comparison
    def factor(self):
        if self._accept("LP"):
            node = self.parse()
            self._expect("RP")
            return node
        return self.comparison()
    # comparison := IDENT EQ (IDENT | STR)
    def comparison(self):
        if self.curr[0] != "IDENT":
            raise SyntaxError("Expected IDENT in comparison")
        left = self.curr[1]
        self._advance()
        self._expect("EQ")
        if self.curr[0] in ("IDENT", "STR"):
            right = self.curr[1]
            self._advance()
        else:
            raise SyntaxError("Expected IDENT or STR after ==")
        # strip quotes if STR
        if right.startswith("'") or right.startswith('"'):
            right = right[1:-1]
        return ("EQ", left, right)

def _eval_ast(node, ctx: Dict[str, str]) -> bool:
    op = node[0]
    if op == "EQ":
        left, right = node[1], node[2]
        lval = str(ctx.get(left, "")).lower()
        rval = str(right).lower()
        return lval == rval
    elif op == "AND":
        return _eval_ast(node[1], ctx) and _eval_ast(node[2], ctx)
    elif op == "OR":
        return _eval_ast(node[1], ctx) or _eval_ast(node[2], ctx)
    else:
        raise ValueError(f"Unknown AST node: {op}")

def rule_match(expr: str, ctx: Dict[str, str]) -> bool:
    try:
        tokens = _tokenize(expr or "")
        ast = _Parser(tokens).parse()
        return _eval_ast(ast, ctx)
    except Exception:
        return False

# ---- Loader & selector -------------------------------------------------------

def load_plans(yaml_path: str) -> List[Plan]:
    if not os.path.exists(yaml_path):
        raise FileNotFoundError(f"plans yaml not found: {yaml_path}")
    with open(yaml_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    plans = []
    for p in data.get("plans", []):
        plans.append(Plan(
            id = p.get("id"),
            applies_if = p.get("applies_if", ""),
            summary = p.get("summary", ""),
            steps = list(p.get("steps", [])),
            scripts = dict(p.get("scripts", {})),
        ))
    return plans

def select_interventions(
    dimension: str,
    severity: str,
    yaml_path: str = "data/plans/plans_minimal_v1.yaml",
    top_k: int = 2
) -> List[Dict[str, Any]]:
    """选择与 (dimension, severity) 匹配的干预卡。

    匹配优先级：
      1) 完全匹配：dimension==X && severity==Y
      2) 维度优先：dimension==X （忽略严重度）
      3) 兜底：所有卡按出现顺序取前 top_k

    返回: [ {id, summary, steps, scripts}, ... ]
    """
    sev_norm = normalize_severity(severity)
    ctx = {"dimension": str(dimension).lower(), "severity": sev_norm}

    plans = load_plans(yaml_path)

    def _match_list(plans, cond) -> List[Plan]:
        out = []
        for p in plans:
            expr = (p.applies_if or "").strip()
            if not expr:
                continue
            # normalize in expr: severity aliases
            expr_norm = re.sub(r"severity\s*==\s*'(严重|中度|良好)'", 
                               lambda m: f"severity=='{normalize_severity(m.group(1))}'", expr)
            expr_norm = expr_norm.replace('"', "'")  # unify quotes
            if rule_match(expr_norm, ctx) and cond(p):
                out.append(p)
        return out

    # 1) 完全匹配
    exact = _match_list(plans, lambda p: True)
    # 如果没有任何 exact（因表达式太严格），再用弱化条件
    if not exact:
        # 2) 维度优先（构造一个仅匹配维度的表达式）
        by_dim = []
        for p in plans:
            expr = (p.applies_if or "").strip()
            if not expr:
                continue
            # 粗略判断是否含有 dimension 条件（或表达式本身仅 dimension）
            if "dimension" in expr and rule_match("dimension=='{}'".format(ctx["dimension"]), ctx):
                by_dim.append(p)
        if by_dim:
            exact = by_dim
        else:
            # 3) 兜底：全部卡片
            exact = plans

    # 去重并裁剪
    seen, results = set(), []
    for p in exact:
        if p.id in seen:
            continue
        seen.add(p.id)
        results.append({
            "id": p.id,
            "summary": p.summary,
            "steps": p.steps,
            "scripts": p.scripts,
        })
        if len(results) >= top_k:
            break
    return results
