
from __future__ import annotations

from typing import List, Dict, Optional
from collections import defaultdict

def aggregate_scores(
    item_scores: List[Dict],
    dim_weights: Optional[Dict[str, float]] = None,
    thresholds: Optional[Dict[str, float]] = None,
) -> Dict:
    """
    聚合单题分数为维度分与整体分，并给出严重性分级。

    Parameters
    ----------
    item_scores : List[Dict]
        每题一条记录（已完成反向题换算），示例：
        {
            "question_id": "Q02",
            "dimension": "communication",
            "score": 4.0,          # 1..5
            "weight": 1.0
        }
    dim_weights : Optional[Dict[str, float]]
        各维度权重（用于整体分加权），默认每个维度 1.0
    thresholds : Optional[Dict[str, float]]
        严重性阈值定义（左闭右开）：
        { "severe": 2.5, "moderate": 3.5 } 表示
        score < 2.5 -> 严重； 2.5 <= score < 3.5 -> 中度； score >= 3.5 -> 良好

    Returns
    -------
    Dict
        {
            "dim_scores": {dimension: score_round3, ...},
            "overall_score": float_round3,
            "severity": {dimension: "严重|中度|良好", ...},
            "overall_severity": "严重|中度|良好"
        }
    """
    if dim_weights is None:
        dim_weights = defaultdict(lambda: 1.0)
    if thresholds is None:
        thresholds = {"severe": 2.5, "moderate": 3.5}

    # 维度内加权
    dim_totals, dim_w = defaultdict(float), defaultdict(float)
    for item in item_scores:
        d = item["dimension"]
        s = float(item["score"])
        w = float(item.get("weight", 1.0))
        dim_totals[d] += s * w
        dim_w[d] += w

    dim_scores = {d: (dim_totals[d] / dim_w[d]) for d in dim_totals if dim_w[d] > 0}

    # overall（维度加权）
    total, total_w = 0.0, 0.0
    for d, s in dim_scores.items():
        w = float(dim_weights.get(d, 1.0))
        total += s * w
        total_w += w
    overall_score = round(total / total_w, 3) if total_w else 0.0

    # 严重性分级
    def classify(x: float) -> str:
        if x < thresholds["severe"]:
            return "严重"
        if x < thresholds["moderate"]:
            return "中度"
        return "良好"

    severity = {d: classify(s) for d, s in dim_scores.items()}
    return {
        "dim_scores": {d: round(s, 3) for d, s in dim_scores.items()},
        "overall_score": overall_score,
        "severity": severity,
        "overall_severity": classify(overall_score),
    }


if __name__ == "__main__":
    # quick sanity check
    items = [
        {"question_id": "Q02", "dimension": "communication", "score": 4.0, "weight": 1.0},
        {"question_id": "Q12", "dimension": "communication", "score": 2.0, "weight": 0.5},
        {"question_id": "Q55", "dimension": "trust", "score": 3.0, "weight": 1.0},
    ]
    print(aggregate_scores(items))
