from __future__ import annotations
from typing import Dict, Any, List
from contextlib import contextmanager
from db.session import SessionLocal
from db.repository import Repo

@contextmanager
def _session_scope():
    sa = SessionLocal()
    try:
        yield sa
        sa.commit()
    except Exception:
        sa.rollback()
        raise
    finally:
        sa.close()

def persist_after_graph(user_id: str, state: Dict[str, Any]):
    """
    在每次 graph.invoke() 后调用，把本次变化写入数据库。
    - 新会话：创建用户/会话
    - 新增消息：messages[-N:] 直接追加
    - 新增执行日志：execution_log[-N:] 直接追加（MVP）
    - 新增答案：answers/item_scores 逐条追加
    - 完成评估：写入 ReportVersion（保留历史版本）
    """
    session_id = state.get("session_id")
    if not session_id:
        return

    with _session_scope() as sa:
        repo = Repo(sa)
        repo.ensure_user(user_id)
        repo.ensure_session(session_id, user_id)

        # 1) 消息（可优化为只写新增，这里直接写入最近若干条由上层控制）
        msgs: List[Dict[str, Any]] = state.get("messages") or []
        if msgs:
            # 生产时建议用“上次同步位置 offset”避免重复；此处简单处理
            repo.append_messages(session_id, msgs[-5:])

        # 2) 执行日志（同上，MVP 仅同步最近记录）
        logs: List[Dict[str, Any]] = state.get("execution_log") or []
        if logs:
            repo.append_execution_logs(session_id, logs[-20:])

        # 3) 答案/打分（只写最新一道；生产可做去重）
        last_score = state.get("last_score")
        if last_score and not last_score.get("needs_clarify"):
            # 找到对应 answers/item_scores 的最后一条
            if state.get("answers"):
                repo.append_answer(session_id, state["answers"][-1])
            if state.get("item_scores"):
                repo.append_item_score(session_id, state["item_scores"][-1])

        # 4) 如果本轮完成了整份量表，生成报告版本
        if state.get("plan_finished"):
            payload = {
                "profile": state.get("profile"),
                "dim_scores": state.get("dim_scores"),
                "overall_score": state.get("overall_score"),
                "overall_severity": state.get("overall_severity"),
                "interventions": state.get("interventions"),
                "report": state.get("report"),
            }
            repo.create_report_version(session_id, payload)
            repo.update_session_status(session_id, "completed")