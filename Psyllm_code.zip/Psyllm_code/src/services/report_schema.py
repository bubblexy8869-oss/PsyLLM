
from __future__ import annotations
from typing import List, Dict, Optional
from pydantic import BaseModel, Field, validator

class Header(BaseModel):
    title: str = "婚姻关系评估报告"
    user_display_name: str
    session_id: str
    report_date: str
    disclaimer: str

class DimensionEntry(BaseModel):
    key: str
    name: str
    score: float
    severity: str
    interpretation: str
    signals: List[str] = Field(default_factory=list)
    suggested_focus: List[str] = Field(default_factory=list)

class InterventionEntry(BaseModel):
    dimension: str
    title: str
    why_this: str
    steps: List[str] = Field(default_factory=list)
    coach_script: Optional[str] = None

class NextStepItem(BaseModel):
    day: int
    tasks: List[str] = Field(default_factory=list)

class NextSteps(BaseModel):
    two_week_plan: List[NextStepItem] = Field(default_factory=list)
    reassessment: Optional[str] = None
    seek_help_signals: List[str] = Field(default_factory=list)

class ReportPayload(BaseModel):
    header: Header
    summary: Dict
    dimensions: List[DimensionEntry]
    intervention_plan: List[InterventionEntry]
    next_steps: NextSteps

    @validator("dimensions", each_item=True)
    def _score_range(cls, v: DimensionEntry):
        assert 0.0 <= v.score <= 5.0, "score must be within 0..5"
        return v
